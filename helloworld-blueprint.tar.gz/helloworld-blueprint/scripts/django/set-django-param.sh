#!/bin/bash

set -e

ctx source instance runtime-properties django_env_param $(ctx target instance runtime_properties django_env_param)


