#!/bin/bash

set -e

ctx logger info "Start install Django"
ctx logger info $(ctx execution-id)

# these runtime properties are used by the start-mysql script.
ctx instance runtime-properties install_django_param "install_django_param"
ctx instance runtime-properties django_env_param "django_env_param"

ctx logger info "Sucessfully installed Django"

