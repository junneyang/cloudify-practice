#!/bin/bash

set -e

ctx logger info "Start install AppTest"
ctx logger info $(ctx execution-id)

ctx logger info $(ctx instance runtime_properties django_env_param)
#ctx logger info $(ctx instance runtime_properties mysql_ip_address)
#ctx logger info $(ctx instance runtime_properties mysql_port)

# these runtime properties are used by the start-mysql script.
ctx instance runtime-properties install_apptest_param "install_apptest_param"

ctx logger info "Sucessfully installed AppTest"

