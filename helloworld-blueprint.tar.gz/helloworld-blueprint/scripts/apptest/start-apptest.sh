#!/bin/bash

set -e

ctx logger info "Start start AppTest"
ctx logger info $(ctx execution-id)

ctx logger info $(ctx instance runtime_properties django_env_param)
ctx logger info $(ctx instance runtime_properties mysql_ip_address)
ctx logger info $(ctx instance runtime_properties mysql_port)


ctx logger info $(ctx node properties port)
ctx logger info $(ctx node properties application_url)
ctx logger info $(ctx node properties startup_script)

# this runtime porperty is used by the stop-mongo script.
ctx instance runtime_properties apptest_pid "654321"

ctx logger info "Sucessfully started AppTest 654321"

ctx logger info "Sucessfully start AppTest"

