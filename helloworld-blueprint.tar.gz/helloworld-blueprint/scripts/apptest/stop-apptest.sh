#!/bin/bash

set -e

ctx logger info "Stop AppTest"
ctx logger info $(ctx instance runtime_properties django_env_param)



PID=$(ctx instance runtime_properties mysql_pid)
ctx logger info $PID

ctx logger info "Sucessfully stopped AppTest (${PID})"
