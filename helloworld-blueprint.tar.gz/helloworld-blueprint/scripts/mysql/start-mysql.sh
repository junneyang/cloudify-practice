#!/bin/bash

set -e

ctx logger info "Start MySQLDB"
PORT=$(ctx node properties port)
install_mysql_param=$(ctx instance runtime_properties install_mysql_param)
ctx logger info $PORT
ctx logger info $install_mysql_param

# this runtime porperty is used by the stop-mongo script.
ctx instance runtime_properties mysql_pid "123456"
ctx instance runtime_properties start_mysql_param "start_mysql_param"

ctx logger info "Sucessfully started MySQLDB 123456"

