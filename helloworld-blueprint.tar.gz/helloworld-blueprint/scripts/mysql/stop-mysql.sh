#!/bin/bash

set -e

ctx logger info "Stop MySQLDB"

PID=$(ctx instance runtime_properties mysql_pid)
install_mysql_param=$(ctx instance runtime_properties install_mysql_param)
start_mysql_param=$(ctx instance runtime_properties start_mysql_param)
ctx logger info $PORT
ctx logger info $install_mysql_param
ctx logger info $start_mysql_param

ctx logger info "Sucessfully stopped MongoDB (${PID})"

