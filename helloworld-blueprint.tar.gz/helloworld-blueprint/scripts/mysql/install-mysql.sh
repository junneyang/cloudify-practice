#!/bin/bash

set -e

ctx logger info "Start install MySQLDB"
ctx logger info $(ctx execution-id)

# these runtime properties are used by the start-mysql script.
ctx instance runtime-properties install_mysql_param "install_mysql_param"

ctx logger info "Sucessfully installed MySQLDB"


